'use strict';
var controllers = angular.module('controllers', []);

/**
 *  controller
 ********************************/
controllers.controller('MasterCtrl', ['$scope', 'DataService', '$location',
    function ($scope, DataService, $location) {
           
        // load JSON data
        var dataPromise = DataService.query('DataSet');
        dataPromise.then(function(data) {
            $scope.DataSet = data;
        }, function(data) {});   

        // active path
            $scope.pathLink = function(route) {
                return route == $location.path();
            };
        // end active path

        // select
	        $scope.SelectItemBind = function(items) {
		        $scope.itemBind = items;
		        $scope.itemSelect = true;
		    };
	    // select

	    var date = new Date();
		$scope.today = ('0' + date.getDate()).slice(-2) + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + date.getFullYear();

	    $scope.listItemCPN = 2;

	    $scope.itemShow = function(){
	    	$scope.listItemCPN++;
	    	$scope.hidePPAdd = true;
	    }

	    $scope.itemBindCreate = function(){
	    	$scope.listItemCPN++;
	    }

	    

	    $scope.itemShowCreate = function(){
	    	if ($scope.practiceName==null && $scope.shippingAddress==null && $scope.cityCreate==null && $scope.DataSet.dropProvinceSelect2=='Select --' && $scope.DataSet.dropCountrySelect2=='Select --' && $scope.phone1Create==null && $scope.phone2Create==null && $scope.phone3Create==null) {
	    		$scope.createFalse = true;
	    	} else $scope.listItemCPN++;
	    }

	    // js ff1
	    	//click on page body
			$("body").click(function(){
			    $(".address-pop-layer").addClass("hide");
			})
			  
			//click Next Consent from Due Date button
			$(".btn-date").click(function(){
			    if($(this).hasClass("btn-red"))
			    {
			      //button is red
			      $(".btn-show-modal-consent-form").click();
			    }
			    else
			    {
			      //button is blue;
			    }
			})
			  
			//click on Park Dental Clinic button
			$(".btn-park-dental-clinic").click(function(event){
			    if($(this).next().hasClass("hide"))
			    {
			      $("body").click();
			      $(this).next().removeClass("hide")
			    }
			    else
			    {
			      $("body").click();
			    }
			    event.stopPropagation()
			  })
			  
			  //click items on Address popup
			  $(".address-pop-layer .btn-address").click(function(){
			    var default_item = $(this).parents(".address-pop-layer").prev();
			    default_item.find(".infos h3").html($(this).find(".infos h3").html());
			    default_item.find(".infos span:eq(0)").html($(this).find(".infos span:eq(0)").html());
			    default_item.find(".infos span:eq(1)").html($(this).find(".infos span:eq(1)").html());
			    
			    $(this).parents(".address-pop-layer").find(".btn-address").removeClass("active");
			    $(this).addClass("active");
			    
			    $(this).parents(".address-pop-layer").addClass("hide");
			  })
			  
			  //click on Address popup
			  $(".address-pop-layer").click(function(event){
			    event.stopPropagation()
			  })
			  
			  //click on Product item in Samples page
			  $(".products-content .product-main").click(function(){
			    $(this).parent().toggleClass("active");
			  })
			  
			  //click dropdown option in dropdown popup
			  $(".dropdown-menu li").click(function(){
			    $(this).parents(".dropdown-default").find(".dropdown-txt .value").html($(this).find("a").html());
			  })
			  
			  //click OK button in YOUR CONSENT FORM HAS BEEN SUBMITTED modal window 
			  $(".btn-ok-for-submit-consent").click(function(){
			    $(".btn-date").removeClass("btn-red").addClass("btn-blue btn-disabled");
			  })
			  
			  //click Remove button in MY ORDER SUMMARY modal window
			  $("#modal-review-your-order .icon-red-btn").click(function(){
			    $(this).parents(".products-order .row").remove();
			  })
			  
			  //click on Rows in Orders page
			  $(".orders-contents .row-pointer").click(function(){
			    $(this).toggleClass("current");
			    if($(this).hasClass("current"))
			    {
			      $(this).next().removeClass("hide");
			    }
			    else
			    {
			      $(this).next().addClass("hide");
			    }
			  })
	    // end js ff1

	}
]);