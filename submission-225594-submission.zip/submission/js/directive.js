'use strict';

/* App Module */
var directives = angular.module('directives', []);

// directive center popup
directives.directive('centerScreen', function ($window) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var window = angular.element($window);

            setPosition();

            window.on('resize', function() {
                setPosition();
            });

            function setPosition() {
                var x = (window.innerHeight() - element.innerHeight())/2,
                    y = (window.innerWidth() - element.innerWidth())/2;

                x = x > 0 ? x : 0;
                y = y > 0 ? y : 0;
                element.css({'top': x, 'left': y});
            }
        }
    }
});

// derective auto width
directives.directive("datepicker", function () {
  return {
    restrict: "A",
    require: "ngModel",
    link: function (scope, elem, attrs, ngModelCtrl) {
      var updateModel = function (dateText) {
        scope.$apply(function () {
          ngModelCtrl.$setViewValue(dateText);
        });
      };
      var options = {
        dateFormat: "dd/mm/yy",
        onSelect: function (dateText) {
          updateModel(dateText);
        }
      };
      elem.datepicker(options);
    }
  }
});
// numbersOnly
directives.directive('numbersOnly', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                if (text) {
                    var transformedInput = text.replace(/[^0-9]/g, '');

                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                return undefined;
            }            
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});