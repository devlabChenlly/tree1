'use strict';
var app = angular.module('app', ['ngRoute', 'services', 'controllers', 'directives','ng.bs.dropdown']);

/**
 * app config route
 ***************************/

app.config(['$routeProvider',
    function($routeProvider) {
        var path = 'views/';
        $routeProvider.
            when('/profile', {
                templateUrl: path + 'profile.html',
                controller: 'MasterCtrl'
            }).
            when('/orders', {
                templateUrl: path + 'orders.html',
                controller: 'MasterCtrl'
            }).
            when('/samples', {
                templateUrl: path + 'samples.html',
                controller: 'MasterCtrl'
            }).
            when('/registration', {
                templateUrl: path + 'registration.html',
                controller: 'MasterCtrl'
            }).
            otherwise({
                redirectTo: '/registration',
            });
    }
]);