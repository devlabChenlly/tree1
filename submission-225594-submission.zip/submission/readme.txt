HTML5 validator:

No Error Found.

=> Please not score down for element angularjs.

CSS3 validator:

No Error Found.

!important: "complete the registration step (add affiliation) to the item's Profile"

Thanks for your review!